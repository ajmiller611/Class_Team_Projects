﻿using System.Web.UI;

namespace HotelTestWebForm.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}