﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSP
{
    class City
    {
        private int x, y;

        public City()
        {
            Random rand = new Random();
            this.x = (int)(rand.Next(0, 200));
            this.y = (int)(rand.Next(0, 200));
        }

        public City(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public int getX()
        {
            return this.x;
        }

        public int getY()
        {
            return this.y;
        }

        public double distanceTo(City city)
        {
            int xDistance = Math.Abs(getX() - city.getX());
            int yDistance = Math.Abs(getY() - city.getY());
            double distance = Math.Sqrt((xDistance * xDistance) + (yDistance * yDistance));

            return distance;
        }

        public string toString()
        {
            return getX() + ", " + getY();
        }
    }
}
