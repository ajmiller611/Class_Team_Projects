﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSP
{
    class GA
    {
        //GA Parameters
        public const Double mutationRate = .015;
        public const int tournamentSize = 5;
        public const Boolean elitism = true;

        //Evolves a population over one generation
        public static Population evolvePopulation(Population pop)
        {
            Population newPopulation = new Population(pop.populationSize(), false);

            //Keep the best individual if elitism is enabled
            int elitismOffset = 0;
            if (elitism)
            {
                newPopulation.saveTour(0, pop.getFittest());
                elitismOffset = 1;
            }

            //Crossover population
            //Loop over the new population's size and create individuals from Current population
            for (int i = elitismOffset; i < newPopulation.populationSize(); i++)
            {
                Tour parent1 = tournamentSelection(pop);
                Tour parent2 = tournamentSelection(pop);
                Tour child = crossover(parent1, parent2);
                newPopulation.saveTour(i, child);
            }

            for (int i = elitismOffset; i < newPopulation.populationSize(); i++)
            {
                mutate(newPopulation.getTour(i));
            }
            return newPopulation;
        }

        //Applies crossover to a set of parents and creates offspring
        public static Tour crossover(Tour parent1, Tour parent2)
        {
            Random rand = new Random();
            //Creates a new child tour
            Tour child = new Tour();

            //Get start and end sub tour positions for parent1's tour
            int startPos = (int)(rand.Next(0, 1) * parent1.tourSize());
            int endPos = (int)(rand.Next(0,1) * parent1.tourSize());

            //Loop and add the sub tour from parent1 to our child
            for (int i = 0; i < child.tourSize(); i++)
                if (startPos < endPos && i > startPos && i < endPos)
                {
                    child.setCity(i, parent1.getCity(i));
                }
                else if (startPos > endPos)
                {
                    if (!(i < startPos && i > endPos))
                    {
                        child.setCity(i, parent1.getCity(i));
                    }
                }
            //Loop through parent2's city tour
            for (int i = 0; i < parent2.tourSize(); i++)
            {
                //if a child does not have a city add it
                if (!child.containsCity(parent2.getCity(i)))
                {
                    //loop to find a spare position in the child's tour
                    for (int ii = 0; ii < child.tourSize(); ii++)
                    {
                        //Spare position found, add city
                        if (child.getCity(ii) == null)
                        {
                            child.setCity(ii, parent2.getCity(i));
                            break;
                        }
                    }
                }
            }
            return child;
        }

        //Mutate a tour using swap mutation
        private static void mutate(Tour tour)
        {
            Random rand = new Random();
            //Loop through tour cities
            for (int tourPos1 = 0; tourPos1 < tour.tourSize(); tourPos1++)
            {
                //Apply a mutation rate
                if (rand.Next(0,1) < mutationRate)
                {
                    //Get a second random position in the tour
                    int tourPos2 = (int)(tour.tourSize() * rand.Next(0,1));

                    //Get the cities at the target poisition in tour
                    City city1 = tour.getCity(tourPos1);
                    City city2 = tour.getCity(tourPos2);

                    tour.setCity(tourPos2, city1);
                    tour.setCity(tourPos1, city2);
                }
            }
        }
        //Selects a tour for crossover
        public static Tour tournamentSelection(Population pop)
        {
            Random rand = new Random();
            Population tournament = new Population(tournamentSize, false);
            for (int i = 0; i < tournamentSize; i++)
            {
                int randomId = (int)(rand.Next(pop.populationSize()));
                tournament.saveTour(i, pop.getTour(randomId));
            }
            Tour fittest = tournament.getFittest();
            return fittest;
        }
    }
}
	
