﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSP
{
    class Population
    {
        //Holds the population of tours
        Tour[] tours;

        //Construct a population 
        public Population(int populationSize, Boolean initialize)
        {
            tours = new Tour[populationSize];
            //if we need to initialise a population of tours to do so
            if (initialize)
            {
                for (int i = 0; i < populationSize; i++)
                {
                    Tour newTour = new Tour();
                    newTour.generateIndividual();
                    saveTour(i, newTour);
                }
            }
        }
        //Savers a tour
        public void saveTour(int index, Tour tour)
        {
            tours[index] = tour;
        }
        //Gets a tour from population
        public Tour getTour(int index)
        {
            return tours[index];
        }

        //Get the best tour in the population
        public Tour getFittest()
        {
            Tour fittest = tours[0];
            //loop through each individual to find the fittest
            for (int i = 1; i < populationSize(); i++)
            {
                if (fittest.getFitness() <= getTour(i).getFitness())
                {
                    fittest = getTour(i);
                }
            }
            return fittest;
        }

        public int populationSize()
        {
            return tours.Length;
        }

    }
}
