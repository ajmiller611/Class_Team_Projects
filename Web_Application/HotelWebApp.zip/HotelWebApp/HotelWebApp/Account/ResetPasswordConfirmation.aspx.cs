﻿using System.Web.UI;

namespace HotelWebApp.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}