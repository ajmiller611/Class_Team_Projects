﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{

    public partial class Main : Form
    {

        public static bool validUser = false;
        public static bool manager = false;
        public static String[,] roomString = new String[6,12];
        public static List<String> roomList = new List<String>();
        public static String[] roomDataForListBox = new String[72];
        public Main()
        {
            for(int a = 0;a < 6;a++)
            {
                for(int b = 0;b < 12;b++)
                {
                    roomString[a, b] = a + "0" + b;
                    if(b >= 10)
                        roomString[a, b] = a + "" + b;
                    roomDataForListBox[(a*6)+b] = roomString[a,0]+roomString[a,1];
                }
                
            }
            SignIn newSignIn = new SignIn();
            newSignIn.Show();
            InitializeComponent();
        }

        public static void updateRooms()
        {
            for(int a = 0;a < 72;a++)
                roomList.Add(roomDataForListBox[a]);
            listBox1.DataSource = roomList;
        }

        public String[,] getRoomList()
        {
            updateRooms();
            String[,] result = roomString;
            return result;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (validUser)
            {
                newTransaction transaction = new newTransaction();
                transaction.Show();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (validUser)
            {
                CancelReservation cancel = new CancelReservation();
                cancel.Show();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (validUser && manager)
            {
                UpdatePricing update = new UpdatePricing();
                update.Show();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (validUser)
            {
                ViewReports view = new ViewReports();
                view.Show();
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (validUser)
            {
                ExistingCustomerReview ExistingCustomer = new ExistingCustomerReview();
                ExistingCustomer.Show();
            }
        }

        

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
