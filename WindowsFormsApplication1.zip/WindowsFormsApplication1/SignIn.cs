﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class SignIn : Form
    {
        String[,] users = new String[3, 3]
            {
            {"KGilbert", "Feanaro0", "staff"},
            {"AMiller", "Feanaro1", "staff"},
            {"HVomend", "Feanaro2", "manager"}
            };
        String[] input = new String[2];
        public SignIn()
        {
            

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int a = 0; a < users.Length-1;a++ )
            {
                if(input[0].CompareTo(users[a,0])==0)
                    if (input[1].CompareTo(users[a,1])==0)
                    {
                        if (users[a, 2].CompareTo("manager") == 0)
                            Main.manager = true;
                        Main.validUser = true;
                        Main.updateRooms();
                        this.Close();
                        a = users.Length;
                    }
            }
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            input[1] = this.textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            input[0] = this.textBox2.Text;
        }
    }
}
