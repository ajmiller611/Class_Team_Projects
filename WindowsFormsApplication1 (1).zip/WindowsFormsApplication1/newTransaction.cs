﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class newTransaction : Form
    {
        String[] customerInfo = new String[15];
        
        public newTransaction()
        {
            InitializeComponent();
            for(int i = 0;i < 15;i++)
        {
        customerInfo[i] = "";
        }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            NewTransactionReview transactionReview = new NewTransactionReview();
            transactionReview.setCustomerInfo(customerInfo);
            transactionReview.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            customerInfo[0] = this.textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            customerInfo[1] = this.textBox2.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            customerInfo[2] = this.textBox3.Text;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            customerInfo[3] = this.comboBox1.GetItemText(this.comboBox1.Items[this.comboBox1.SelectedIndex]);
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            customerInfo[4] = this.textBox4.Text;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            customerInfo[5] = this.textBox5.Text;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            customerInfo[6] = this.textBox6.Text;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            customerInfo[9] = this.comboBox2.GetItemText(this.comboBox2.Items[this.comboBox2.SelectedIndex]);
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            customerInfo[10] = this.textBox7.Text;
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            customerInfo[11] = this.textBox8.Text;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            customerInfo[12] = this.comboBox3.GetItemText(this.comboBox3.Items[this.comboBox3.SelectedIndex]);
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            customerInfo[13] = this.textBox9.Text;
        }

        private void newTransaction_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            customerInfo[7] = dateTimePicker1.Value.ToShortDateString();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            customerInfo[8] = dateTimePicker2.Value.ToShortDateString();
        }
        
    }
}
