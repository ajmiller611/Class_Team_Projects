﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class NewTransactionReview : Form
    {
        String[] customer = new String[15];
        String customerReview = "";
        public NewTransactionReview()
        {
            
            InitializeComponent();
        }
        private void NewTransactionReview_Load(object sender, EventArgs e)
        {
            
        }
        public void setCustomerInfo(String[] input)
        {
            customer = input;
            customerReview += "Please review the follow trasnsaction details:";
            customerReview += "\nName: " + customer[0];
            customerReview += "\nAddress: " + customer[1];
            customerReview += "\n" + customer[2] + " " + customer[3] + " " + customer[4];
            customerReview += "\nPhone number: " + customer[5];
            customerReview += "\nEmail Address: " + customer[6];
            customerReview += "\nFrom " + customer[7] + " until " + customer[8];
            customerReview += "\nPayment Type: " + customer[9];
            customerReview += "\nRoom number: " + customer[14];
            richTextBox1.Text = customerReview;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
    }
}
