﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace TestWebForms
{
    public partial class Reservation : System.Web.UI.Page
    {
        string sql;
        SqlCommand command;
        protected void Page_Load(object sender, EventArgs e)
        {
            string connetionString = null;
            SqlConnection conn ;
            
			connetionString = @"Data Source=(LocalDb)\v11.0;AttachDbFilename=C:\Users\Andrew\Desktop\TestWebForms\TestWebForms\App_Data\aspnet-TestWebForms-20150302012141.mdf;Initial Catalog=aspnet-TestWebForms-20150302012141;Integrated Security=True";
            conn = new SqlConnection(connetionString);
            sql = "SELECT RoomID FROM Room";
            try
            {
                conn.Open();
                //test.Text = "Connection Open ! ";
                command = new SqlCommand(sql, conn);
                SqlDataReader data = command.ExecuteReader();
                while (data.Read())
                {
                    test.Text += data.GetValue(0);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                test.Text = "Can not open connection ! ";
            }
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            DateTime x = StartDate.SelectedDate;
            DateTime y = EndDate.SelectedDate;
            DateTime z = new DateTime();
            if (x == z)
            {
                StartDateValidation.IsValid = false;
                return;
            }
            if (y == z)
            {
                EndDateValidation.IsValid = false;
                return;
            }

            //sql = "SELECT RoomID FROM Room";
            //sql = "SELECT StartDate, EndDate, NonSmoking, Oceanview, Availability FROM Room WHERE Oceanview = True, NonSmoking = True, Availability = Vacant, EndDate >= " + StartDate.SelectedDate + " OR EndDate = null";
        }

        protected void Clear_Click(object sender, EventArgs e)
        {

        }
    }
}