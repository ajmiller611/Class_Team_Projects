﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace TestWebForms
{
    public partial class Reservation : System.Web.UI.Page
    {
        string sql;
        string connetionString;
        SqlCommand command;
        SqlConnection conn;
        protected void Page_Load(object sender, EventArgs e)
        {
            //check to see if page is loading from being submitted from clicking the button
            if (Page.IsPostBack)
            {

                connetionString = @"Data Source=(LocalDb)\v11.0;AttachDbFilename=C:\Users\Andrew\Desktop\TestWebForms\TestWebForms\App_Data\aspnet-TestWebForms-20150302012141.mdf;Initial Catalog=aspnet-TestWebForms-20150302012141;Integrated Security=True";
                conn = new SqlConnection(connetionString);
                //sql = "SELECT RoomID FROM Room";
                try
                {
                    conn.Open();
                    //test.Text = "Connection Open ! ";
                    //command = new SqlCommand(sql, conn);
                    //SqlDataReader data = command.ExecuteReader();
                    //while (data.Read())
                    //{
                        //test.Text += data.GetValue(0);
                    //}
                    //conn.Close();
                }
                catch (Exception ex)
                {
                    test.Text = "Can not open connection ! ";
                }
            }
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            DateTime x = StartDate.SelectedDate;
            DateTime y = EndDate.SelectedDate;
            DateTime z = new DateTime();
            if (x == z)
            {
                StartDateValidation.IsValid = false;
                return;
            }
            if (y == z)
            {
                EndDateValidation.IsValid = false;
                return;
            }
            if (x > y)
            {
                EndDateAfterStartDateValidation.IsValid = false;
                return;
            }


            if (Smoking.Checked)
            {
                sql = "SELECT RoomID FROM Room WHERE Availability = 'Vacant' AND Smoking = 1 AND (EndDate >= '" + StartDate.SelectedDate + "' OR EndDate IS NULL) AND (OceanView = 1 OR OceanView = 0)";
                //sql = "SELECT StartDate,EndDate,Smoking,OceanView,Availability FROM Room WHERE Availability = 'Vacant' AND Smoking = 1 AND (EndDate >= '" + StartDate.SelectedDate.ToShortDateString() + "' OR EndDate IS NULL) AND (OceanView = 1 OR OceanView = 0)";
            }
            else if (OceanView.Checked)
            {
                //sql = "SELECT StartDate, EndDate, Smoking, OceanView, Availability FROM Room WHERE OceanView = True, Smoking = False, Availability = 'Vacant', EndDate >= " + StartDate.SelectedDate + " OR EndDate = null";
            }
            else if (Smoking.Checked && OceanView.Checked)
            {
                //sql = "SELECT StartDate, EndDate, Smoking, OceanView, Availability FROM Room WHERE OceanView = True, Smoking = True, Availability = 'Vacant', EndDate >= " + StartDate.SelectedDate + " OR EndDate = null";
            }
            else
            {
                //sql = "SELECT StartDate, EndDate, Smoking, OceanView, Availability FROM Room WHERE OceanView = True, Smoking = False, Availability = 'Vacant', EndDate >= " + StartDate.SelectedDate + " OR EndDate = null, OceanView = False";
            }


            connetionString = @"Data Source=(LocalDb)\v11.0;AttachDbFilename=C:\Users\Andrew\Desktop\TestWebForms\TestWebForms\App_Data\aspnet-TestWebForms-20150302012141.mdf;Initial Catalog=aspnet-TestWebForms-20150302012141;Integrated Security=True";
            //create database connection
            conn = new SqlConnection(connetionString);

            /*
             * test array to hold room numbers from the query. Note: Have to figure out a way to deal with the size since arrays are fixed size.
             * Thinking of making an array with max number of rooms as size and then passing the array to a method that would then go through and put the cells with data into an array list
             */
            Object[] rooms = new Object[5];
            try
            {
                conn.Open();
                //create command to run sql statement
                command = new SqlCommand(sql, conn);

                //data reader to get the query result from
                SqlDataReader data = command.ExecuteReader();

                //data.GetValues(rooms);    This takes an array as the parameter and it said it puts the values into the array but it wasnt working
                for (int a = 0; a < rooms.Length; a++)
                {
                    //checks if there is data to read and returns boolean
                    if (data.Read())
                        rooms[a] = data.GetValue(a);  //uses index as parameter so im assuming that query data is stored in an array or some type of data structure that uses the index we pass to it

                    //test.Text is writing to the paragraph tag near the top of the page that im using to test what is being returned by the query
                    test.Text += rooms[a] + " ";
                }
                    //while (data.Read())
                    //{
                        //test.Text += data.GetValues();
                    //}
                conn.Close();
            }
            catch (Exception ex)
            {
                //test.Text = "Can not open connection ! ";
            }
        }

        protected void Clear_Click(object sender, EventArgs e)
        {

        }
    }
}