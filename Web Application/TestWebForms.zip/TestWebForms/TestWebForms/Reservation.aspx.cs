﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace TestWebForms
{
    public partial class Reservation : System.Web.UI.Page
    {
        string sql;
        string connetionString;
        SqlCommand command;
        SqlConnection conn;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack)
            {

                connetionString = @"Data Source=(LocalDb)\v11.0;AttachDbFilename=C:\Users\Andrew\Desktop\TestWebForms\TestWebForms\App_Data\aspnet-TestWebForms-20150302012141.mdf;Initial Catalog=aspnet-TestWebForms-20150302012141;Integrated Security=True";
                conn = new SqlConnection(connetionString);
                //sql = "SELECT RoomID FROM Room";
                try
                {
                    conn.Open();
                    //test.Text = "Connection Open ! ";
                    //command = new SqlCommand(sql, conn);
                    //SqlDataReader data = command.ExecuteReader();
                    //while (data.Read())
                    //{
                        //test.Text += data.GetValue(0);
                    //}
                    //conn.Close();
                }
                catch (Exception ex)
                {
                    test.Text = "Can not open connection ! ";
                }
            }
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            DateTime x = StartDate.SelectedDate;
            DateTime y = EndDate.SelectedDate;
            DateTime z = new DateTime();
            if (x == z)
            {
                StartDateValidation.IsValid = false;
                return;
            }
            if (y == z)
            {
                EndDateValidation.IsValid = false;
                return;
            }
            if (x > y)
            {
                EndDateAfterStartDateValidation.IsValid = false;
                return;
            }


            if (Smoking.Checked)
            {
                sql = "SELECT RoomID FROM Room WHERE Availability = 'Vacant' AND Smoking = 1 AND (EndDate >= '" + StartDate.SelectedDate + "' OR EndDate IS NULL) AND (OceanView = 1 OR OceanView = 0)";
                //sql = "SELECT StartDate,EndDate,Smoking,OceanView,Availability FROM Room WHERE Availability = 'Vacant' AND Smoking = 1 AND (EndDate >= '" + StartDate.SelectedDate.ToShortDateString() + "' OR EndDate IS NULL) AND (OceanView = 1 OR OceanView = 0)";
            }
            else if (OceanView.Checked)
            {
                //sql = "SELECT StartDate, EndDate, Smoking, OceanView, Availability FROM Room WHERE OceanView = True, Smoking = False, Availability = 'Vacant', EndDate >= " + StartDate.SelectedDate + " OR EndDate = null";
            }
            else if (Smoking.Checked && OceanView.Checked)
            {
                //sql = "SELECT StartDate, EndDate, Smoking, OceanView, Availability FROM Room WHERE OceanView = True, Smoking = True, Availability = 'Vacant', EndDate >= " + StartDate.SelectedDate + " OR EndDate = null";
            }
            else
            {
                //sql = "SELECT StartDate, EndDate, Smoking, OceanView, Availability FROM Room WHERE OceanView = True, Smoking = False, Availability = 'Vacant', EndDate >= " + StartDate.SelectedDate + " OR EndDate = null, OceanView = False";
            }
            connetionString = @"Data Source=(LocalDb)\v11.0;AttachDbFilename=C:\Users\Andrew\Desktop\TestWebForms\TestWebForms\App_Data\aspnet-TestWebForms-20150302012141.mdf;Initial Catalog=aspnet-TestWebForms-20150302012141;Integrated Security=True";
            conn = new SqlConnection(connetionString);
            Object[] rooms = new Object[5];
            try
            {
                conn.Open();
                command = new SqlCommand(sql, conn);
                SqlDataReader data = command.ExecuteReader();
                //data.GetValues(rooms);
                for (int a = 0; a < rooms.Length; a++)
                {
                    if (data.Read())
                        rooms[a] = data.GetValue(a);
                    test.Text += rooms[a] + " ";
                }
                    //while (data.Read())
                    //{
                        //test.Text += data.GetValues();
                    //}
                conn.Close();
            }
            catch (Exception ex)
            {
                //test.Text = "Can not open connection ! ";
            }
        }

        protected void Clear_Click(object sender, EventArgs e)
        {

        }
    }
}