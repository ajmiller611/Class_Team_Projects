﻿using System.Web.UI;

namespace TestWebForms.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}