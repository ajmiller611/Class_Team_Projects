namespace TestWebForms.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Zip : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
