﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class newTransaction : Form
    {

        String[] customerInfo = new String[16];
        
        public newTransaction()
        {
            InitializeComponent();
            for(int i = 0;i < 16;i++)
        {
        customerInfo[i] = "";
        }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            NewTransactionReview transactionReview = new NewTransactionReview();
            transactionReview.setCustomerInfo(customerInfo);
            transactionReview.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            customerInfo[4] = this.comboBox1.GetItemText(this.comboBox1.Items[this.comboBox1.SelectedIndex]);
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            customerInfo[10] = this.comboBox2.GetItemText(this.comboBox2.Items[this.comboBox2.SelectedIndex]);
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            customerInfo[14] = this.comboBox3.GetItemText(this.comboBox3.Items[this.comboBox3.SelectedIndex]);
        }


        private void newTransaction_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            customerInfo[8] = dateTimePicker1.Value.ToShortDateString();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            customerInfo[9] = dateTimePicker2.Value.ToShortDateString();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

  
        

        

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox3_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox5_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox6_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox7_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox8_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox9_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox10_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox11_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox11_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox11.SelectionStart = 0;
        }

        private void maskedTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox1.SelectionStart = 0;
        }

        private void maskedTextBox2_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox2.SelectionStart = 0;
        }

        private void maskedTextBox3_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox3.SelectionStart = 0;
        }

        private void maskedTextBox4_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox4.SelectionStart = 0;
        }

        private void maskedTextBox6_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox6.SelectionStart = 0;
        }

        private void maskedTextBox7_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox7.SelectionStart = 0;
        }

        private void maskedTextBox9_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox9.SelectionStart = 0;
        }

        private void maskedTextBox10_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox10.SelectionStart = 0;
        }

        private void maskedTextBox11_Validated(object sender, EventArgs e)
        {
            customerInfo[0] = maskedTextBox11.Text;
        }

        private void maskedTextBox1_Validated(object sender, EventArgs e)
        {
            customerInfo[1] = maskedTextBox1.Text;
        }

        private void maskedTextBox2_Validated(object sender, EventArgs e)
        {
            customerInfo[2] = maskedTextBox2.Text;
        }

        private void maskedTextBox3_Validated(object sender, EventArgs e)
        {
            customerInfo[3] = maskedTextBox3.Text;
        }

        private void maskedTextBox4_Validated(object sender, EventArgs e)
        {
            customerInfo[5] = maskedTextBox4.Text;
        }

        private void maskedTextBox5_Validated(object sender, EventArgs e)
        {
            customerInfo[6] = maskedTextBox5.Text;
        }


        private void maskedTextBox6_Validated(object sender, EventArgs e)
        {
            customerInfo[7] = maskedTextBox6.Text;
        }

        private void maskedTextBox7_Validated(object sender, EventArgs e)
        {
            customerInfo[11] = maskedTextBox7.Text;
        }

        private void maskedTextBox9_Validated(object sender, EventArgs e)
        {
            customerInfo[13] = maskedTextBox9.Text;
        }

        private void maskedTextBox10_Validated(object sender, EventArgs e)
        {
            customerInfo[15] = maskedTextBox10.Text;
        }

        
        
    }
}
